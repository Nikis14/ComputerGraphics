﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turn_BasedPolygon
{

    public partial class Form1 : Form
    {
        LinkedList<Point> polygon;
        List<Point> allpoints;
        Bitmap bmp;
        bool add_point = false;

        public Form1()
        {
            InitializeComponent();
            polygon = new LinkedList<Point>();
            allpoints = new List<Point>();
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            bmp = (Bitmap)pictureBox1.Image;
            pictureBox1.Image = bmp;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            polygon = new LinkedList<Point>();
            allpoints = new List<Point>();
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
        }

        private void redraw()
        {
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            var pen_line = new Pen(Color.Black, 1);
            var pen_point = new Pen(Color.Red, 3);
            var g = Graphics.FromImage(pictureBox1.Image);
            for (int i = 0; i < polygon.Count - 1; i++)
            { 
                g.DrawLine(pen_line, polygon.ElementAt(i), polygon.ElementAt(i + 1));
            }
            foreach (var item in allpoints)
            {
                g.DrawEllipse(pen_point, item.X-1, item.Y-1, 2, 2);
            }
            g.DrawLine(pen_line, polygon.Last(), polygon.First());
            g.Dispose();
            pen_line.Dispose();
            pen_point.Dispose();
            pictureBox1.Invalidate();
        }

        private bool IsInPolygon(Point p)
        {
            List<Point> poly = polygon.ToList();
            Point p1, p2;
            bool inside = false;

            if (poly.Count < 3)
            {
                return inside;
            }

            var oldPoint = new Point(
                poly[poly.Count - 1].X, poly[poly.Count - 1].Y);

            for (int i = 0; i < poly.Count; i++)
            {
                var newPoint = new Point(poly[i].X, poly[i].Y);

                if (newPoint.X > oldPoint.X)
                {
                    p1 = oldPoint;
                    p2 = newPoint;
                }
                else
                {
                    p1 = newPoint;
                    p2 = oldPoint;
                }

                if ((newPoint.X < p.X) == (p.X <= oldPoint.X)
                    && (p.Y - (long)p1.Y) * (p2.X - p1.X)
                    < (p2.Y - (long)p1.Y) * (p.X - p1.X))
                {
                    inside = !inside;
                }

                oldPoint = newPoint;
            }

            return inside;
        }

        private bool AllPointstoUtmostLeft(Point new_pt, Point pol_pt)
        {
            foreach (var item in polygon)
            {
                if (pol_pt != item)
                {
                    double res_curr = (item.X - new_pt.X) * (pol_pt.Y - new_pt.Y) - (item.Y - new_pt.Y) * (pol_pt.X - new_pt.X);
                    if (res_curr > 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private bool AllPointstoUtmostRight(Point new_pt, Point pol_pt)
        {
            foreach (var item in polygon)
            {
                if (pol_pt != item)
                {
                    double res_curr = (item.X - new_pt.X) * (pol_pt.Y - new_pt.Y) - (item.Y - new_pt.Y) * (pol_pt.X - new_pt.X);
                    if (res_curr < 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void RecalculatePolygon(Point new_pt)
        {
            Point LeftTouch = new Point();
            Point RightTouch = new Point();
            LinkedListNode<Point> start = polygon.First;
            LinkedList<Point> new_polygon = new LinkedList<Point>();
            foreach (var pt in polygon)
            {
                if (AllPointstoUtmostLeft(new_pt, pt))
                {
                    LeftTouch = pt;
                }
                if (AllPointstoUtmostRight(new_pt, pt))
                {
                    RightTouch = pt;
                }
            }
            new_polygon.AddLast(LeftTouch);
            new_polygon.AddLast(new_pt);
            LinkedListNode<Point> current = polygon.FindLast(RightTouch);
            while(current.Value != LeftTouch)
            {
                new_polygon.AddLast(current.Value);
                if (current == polygon.Last)
                {
                    current = polygon.First;
                }
                else
                {
                    current = current.Next;
                }
            }
            if (new_polygon.Count == 3)
            {
                new_polygon = new LinkedList<Point>();
                new_polygon.AddLast(LeftTouch);
                new_polygon.AddLast(new_pt);
                current = polygon.FindLast(RightTouch);
                while (current.Value != LeftTouch)
                {
                    new_polygon.AddLast(current.Value);
                    if (current == polygon.First)
                    {
                        current = polygon.Last;
                    }
                    else
                    {
                        current = current.Previous;
                    }
                }
            }
            polygon = new_polygon;

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            Point curr = new Point(e.X, e.Y);
            if (add_point == true)
            {
                allpoints.Add(curr);
                add_point = false;
                allpoints.Add(curr);
                if (polygon.Count < 3)
                {
                    polygon.AddLast(curr);
                    
                }
                else
                {
                    if (!IsInPolygon(curr))
                    {
                        RecalculatePolygon(curr);
                        
                    }
                }
                redraw();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            add_point = true;
        }

    }
}
